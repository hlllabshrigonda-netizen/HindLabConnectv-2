package com.hindlab.connect.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AttendanceDao {
    @Insert
    suspend fun insert(item: AttendanceEntity)

    @Query("SELECT * FROM attendance ORDER BY timestamp DESC")
    fun observeAll(): Flow<List<AttendanceEntity>>

    @Query("SELECT * FROM attendance WHERE employeeId = :employeeId ORDER BY timestamp DESC")
    fun observeEmployee(employeeId: String): Flow<List<AttendanceEntity>>
}
