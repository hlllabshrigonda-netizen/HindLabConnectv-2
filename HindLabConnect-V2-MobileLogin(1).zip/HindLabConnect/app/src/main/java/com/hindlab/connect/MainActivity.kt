package com.hindlab.connect

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.room.Room
import com.google.android.gms.location.LocationServices
import com.hindlab.connect.auth.*
import com.hindlab.connect.data.*
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "hind_lab_connect.db"
        ).build()

        val repo = AttendanceRepository(db.attendanceDao())

        setContent {
            HindLabTheme {
                App(repo)
            }
        }
    }
}

@Composable
fun App(repo: AttendanceRepository) {
    var session by remember { mutableStateOf<UserSession?>(null) }

    if (session == null) {
        LoginScreen { session = it }
    } else {
        if (session!!.role == Role.EMPLOYEE) {
            EmployeeHome(session!!, repo) { session = null }
        } else {
            AdminHome(session!!, repo) { session = null }
        }
    }
}

@Composable
fun LoginScreen(onLogin: (UserSession) -> Unit) {
    var mobile by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }

    Surface(Modifier.fillMaxSize()) {
        Column(
            modifier = Modifier.fillMaxSize().padding(24.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("Hind Lab Connect", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("Employee Attendance System", color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(32.dp))

            OutlinedTextField(mobile, { mobile = it }, label = { Text("Mobile Number") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(password, { password = it }, label = { Text("Password") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(18.dp))

            Button(
                onClick = {
                    val user = DemoAuth.login(mobile.trim(), password)
                    if (user != null) onLogin(user) else error = "Invalid ID or password"
                },
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text("LOGIN") }

            if (error.isNotEmpty()) {
                Spacer(Modifier.height(12.dp))
                Text(error, color = MaterialTheme.colorScheme.error)
            }

            Spacer(Modifier.height(28.dp))
            Text("Test Employee: 8379934550 / Lab123@@")
            Text("Demo Admin: admin / admin123")
        }
    }
}

@Composable
fun EmployeeHome(session: UserSession, repo: AttendanceRepository, logout: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val records by repo.employee(session.id).collectAsState(initial = emptyList())
    var attendanceType by remember { mutableStateOf<String?>(null) }
    var pendingPhoto by remember { mutableStateOf<String?>(null) }
    var status by remember { mutableStateOf("Ready") }

    val photoFile = remember {
        File(context.filesDir, "attendance").apply { mkdirs() }
    }

    fun newPhotoUri(): Pair<Uri, String> {
        val file = File(photoFile, "selfie_${System.currentTimeMillis()}.jpg")
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        return uri to file.absolutePath
    }

    var photoPath by remember { mutableStateOf<String?>(null) }

    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok && attendanceType != null && photoPath != null) {
            scope.launch {
                val fused = LocationServices.getFusedLocationProviderClient(context)
                try {
                    @Suppress("MissingPermission")
                    fused.lastLocation.addOnSuccessListener { location ->
                        if (location == null) {
                            status = "Unable to get location. Turn on GPS and try again."
                            return@addOnSuccessListener
                        }

                        val result = FloatArray(1)
                        android.location.Location.distanceBetween(
                            location.latitude, location.longitude,
                            OfficeConfig.OFFICE_LATITUDE, OfficeConfig.OFFICE_LONGITUDE,
                            result
                        )
                        val distance = result[0]

                        if (distance <= OfficeConfig.GEOFENCE_RADIUS_METERS) {
                            scope.launch {
                                repo.add(
                                    AttendanceEntity(
                                        employeeId = session.id,
                                        employeeName = session.name,
                                        type = attendanceType!!,
                                        timestamp = System.currentTimeMillis(),
                                        latitude = location.latitude,
                                        longitude = location.longitude,
                                        distanceMeters = distance,
                                        selfiePath = photoPath!!,
                                    )
                                )
                                status = "${attendanceType!!.replace("_", " ")} successful • ${distance.toInt()} m"
                                attendanceType = null
                            }
                        } else {
                            status = "Outside 100 m office radius • ${distance.toInt()} m"
                            File(photoPath!!).delete()
                        }
                    }
                } catch (e: Exception) {
                    status = "Location error: ${e.message ?: "unknown error"}"
                }
            }
        } else {
            status = "Selfie cancelled"
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        val cameraOk = result[Manifest.permission.CAMERA] == true ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        val locationOk = result[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

        if (cameraOk && locationOk && attendanceType != null) {
            val (uri, path) = newPhotoUri()
            photoPath = path
            cameraLauncher.launch(uri)
        } else {
            status = "Camera and Location permissions are required."
        }
    }

    fun startAttendance(type: String) {
        attendanceType = type
        permissionLauncher.launch(
            arrayOf(
                Manifest.permission.CAMERA,
                Manifest.permission.ACCESS_FINE_LOCATION
            )
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Hind Lab Connect") },
                actions = { TextButton(onClick = logout) { Text("Logout") } }
            )
        }
    ) { pad ->
        LazyColumn(
            modifier = Modifier.padding(pad).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text("Good Morning, ${session.name} 👋", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(OfficeConfig.OFFICE_NAME, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            item {
                Card(shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(20.dp)) {
                        Text("Today's Attendance", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        Text(status)
                        Spacer(Modifier.height(16.dp))
                        Button(
                            onClick = { startAttendance("CHECK_IN") },
                            modifier = Modifier.fillMaxWidth().height(52.dp)
                        ) { Text("📸  CHECK IN") }
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = { startAttendance("CHECK_OUT") },
                            modifier = Modifier.fillMaxWidth().height(52.dp)
                        ) { Text("🏁  CHECK OUT") }
                    }
                }
            }

            item {
                Text("Recent Attendance", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }

            items(records.take(20)) { item ->
                AttendanceRow(item)
            }
        }
    }
}

@Composable
fun AttendanceRow(item: AttendanceEntity) {
    val date = SimpleDateFormat("dd MMM yyyy • hh:mm a", Locale.getDefault()).format(Date(item.timestamp))
    Card {
        Column(Modifier.padding(16.dp).fillMaxWidth()) {
            Text(item.type.replace("_", " "), fontWeight = FontWeight.Bold)
            Text(date)
            Text("GPS: ${item.distanceMeters.toInt()} m from office")
        }
    }
}

@Composable
fun AdminHome(session: UserSession, repo: AttendanceRepository, logout: () -> Unit) {
    val records by repo.all.collectAsState(initial = emptyList())

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Admin Dashboard") },
                actions = { TextButton(onClick = logout) { Text("Logout") } }
            )
        }
    ) { pad ->
        LazyColumn(
            modifier = Modifier.padding(pad).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text("Hind Lab Connect", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Attendance Management", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            item {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    StatCard("Today's Logs", records.size.toString(), Modifier.weight(1f))
                    StatCard("Present", records.count { it.status == "PRESENT" }.toString(), Modifier.weight(1f))
                }
            }

            item {
                Text("Latest Attendance", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }

            items(records.take(50)) { AttendanceRow(it) }
        }
    }
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun HindLabTheme(content: @Composable () -> Unit) {
    val colors = lightColorScheme(
        primary = androidx.compose.ui.graphics.Color(0xFF1565C0),
        secondary = androidx.compose.ui.graphics.Color(0xFF00897B),
        background = androidx.compose.ui.graphics.Color(0xFFF7F9FC),
        surface = androidx.compose.ui.graphics.Color.White
    )
    MaterialTheme(colorScheme = colors, content = content)
}
