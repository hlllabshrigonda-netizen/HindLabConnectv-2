package com.hindlab.connect

object OfficeConfig {
    const val OFFICE_NAME = "Hind Lab Connect – Shrigonda"
    const val OFFICE_ADDRESS =
        "Hind Labs Diagnostic Centre, Limpangaon Rd, Shrigonda, Maharashtra 413701"

    // TODO: Replace with the exact Google Maps pin coordinates before production.
    const val OFFICE_LATITUDE = 18.000000
    const val OFFICE_LONGITUDE = 74.000000

    const val GEOFENCE_RADIUS_METERS = 100f
}
