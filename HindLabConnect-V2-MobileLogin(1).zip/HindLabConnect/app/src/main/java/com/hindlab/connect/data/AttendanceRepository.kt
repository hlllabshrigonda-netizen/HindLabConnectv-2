package com.hindlab.connect.data

class AttendanceRepository(private val dao: AttendanceDao) {
    val all = dao.observeAll()
    fun employee(id: String) = dao.observeEmployee(id)
    suspend fun add(item: AttendanceEntity) = dao.insert(item)
}
