package com.hindlab.connect.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [AttendanceEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun attendanceDao(): AttendanceDao
}
