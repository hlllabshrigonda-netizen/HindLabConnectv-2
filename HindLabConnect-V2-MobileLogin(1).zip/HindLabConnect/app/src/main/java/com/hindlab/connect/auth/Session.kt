package com.hindlab.connect.auth

data class UserSession(
    val id: String,
    val name: String,
    val role: Role
)

enum class Role { EMPLOYEE, ADMIN }

object DemoAuth {
    fun login(mobile: String, password: String): UserSession? = when {
        mobile == "8379934550" && password == "Lab123@@" ->
            UserSession("8379934550", "Employee", Role.EMPLOYEE)
        mobile == "admin" && password == "admin123" ->
            UserSession("admin", "Administrator", Role.ADMIN)
        else -> null
    }
}
