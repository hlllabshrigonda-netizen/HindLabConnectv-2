# Hind Lab Connect — Android Employee Attendance

Android starter project for selfie + GPS attendance for Hind Lab Connect, Shrigonda.

## Included
- Employee/Admin login demo
- Check-in and check-out
- Front-camera selfie capture
- GPS permission + distance calculation
- 100-meter geofence
- Local Room attendance history
- Monthly summary
- Admin attendance list
- Clean Jetpack Compose UI

## Office
Hind Labs Diagnostic Centre, Limpangaon Rd, Shrigonda, Maharashtra 413701.

IMPORTANT: The Google Maps link supplied in the conversation did not expose a reliable destination latitude/longitude through the public fetch. Therefore the app uses placeholder coordinates in `OfficeConfig.kt`.
Before production use, replace `OFFICE_LATITUDE` and `OFFICE_LONGITUDE` with the exact pin coordinates.

## Demo accounts
Employee:
- ID: HL001
- Password: 1234

Admin:
- ID: admin
- Password: admin123

## Build
Open this folder in Android Studio (Ladybug or newer recommended), let Gradle sync, then Run on an Android device.

The project is intentionally local-only for the first working build. For real multi-device deployment, replace the demo repository with Firebase/Supabase/your REST API and add secure authentication.

## Permissions
The app requests:
- Camera
- Fine/coarse location

Location is requested only when the user starts attendance verification.
