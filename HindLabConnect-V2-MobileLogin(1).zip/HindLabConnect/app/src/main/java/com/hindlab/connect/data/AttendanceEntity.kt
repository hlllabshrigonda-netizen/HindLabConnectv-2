package com.hindlab.connect.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "attendance")
data class AttendanceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val employeeId: String,
    val employeeName: String,
    val type: String, // CHECK_IN or CHECK_OUT
    val timestamp: Long,
    val latitude: Double,
    val longitude: Double,
    val distanceMeters: Float,
    val selfiePath: String,
    val status: String = "PRESENT"
)
